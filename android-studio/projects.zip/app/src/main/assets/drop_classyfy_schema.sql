drop table if exists categories;
drop table if exists folders;
drop table if exists child_nodes;
drop table if exists nodes;
drop table if exists models;
drop view if exists all_nodes;